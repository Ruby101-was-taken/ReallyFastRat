Open each file in paint.net
There are at least 2 layers in each file.
The lower one shows the rat. Do not edit this as this will not been shown in game. This layer is only to reference the player sprite (reference!??!?)
Drawing should be done in the layer above (You are free to add more layers to this too)
Some contain an extra layer that contains something I felt was important to mention

Save each hat as a .PNG file, not as a .PDN
Each file should be placed in a folder with the name of the hat.
See the "top" folder for details